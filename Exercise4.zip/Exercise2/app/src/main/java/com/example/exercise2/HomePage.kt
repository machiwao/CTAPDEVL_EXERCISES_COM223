package com.example.exercise2

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home_page)
        val txtUsername = findViewById<TextView>(R.id.txtUsername)
        val imgToProfile = findViewById<ImageView>(R.id.imgToProfile)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->

            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            val loggedUser = intent.getStringExtra("loggedUsername")
            txtUsername.setText(loggedUser)
            imgToProfile.setOnClickListener {
                val toProfile = Intent(this, UserProfilePageActivity::class.java)
                toProfile.putExtra("loggedUsername", loggedUser)
                startActivity(toProfile)
            }

            insets
        }
    }
}