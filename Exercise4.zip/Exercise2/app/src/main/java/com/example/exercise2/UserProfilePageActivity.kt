package com.example.exercise2

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import de.hdodenhof.circleimageview.CircleImageView

class UserProfilePageActivity : AppCompatActivity() {
    private lateinit var pickProfileImageLauncher: ActivityResultLauncher<Intent>
    private lateinit var pickPostImageLauncher: ActivityResultLauncher<Intent>

    private lateinit var imgProfilePicture: CircleImageView
    private lateinit var imageViewProfile: ImageView
    private lateinit var imgPost1: ImageView
    private lateinit var txtUsername: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_user_profile_page)

        txtUsername = findViewById(R.id.txtUserName)
        txtUsername.text = intent.getStringExtra("loggedUsername")

        imgProfilePicture = findViewById(R.id.imgProfilePicture)
        imageViewProfile = findViewById(R.id.imageViewProfile)
        imgPost1 = findViewById(R.id.imgPost1)

        val btnEditProfile: Button = findViewById(R.id.btnEditProfile)
        val imgAddPost: ImageView = findViewById(R.id.imgAddPost)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        pickProfileImageLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uri = result.data?.data
                uri?.let {
                    imgProfilePicture.setImageURI(it)
                    imageViewProfile.setImageURI(it)
                }
            }
        }

        pickPostImageLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val uri = result.data?.data
                uri?.let {
                    imgPost1.setImageURI(it)
                }
            }
        }

        btnEditProfile.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
            }
            pickProfileImageLauncher.launch(intent)
        }

        imgAddPost.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
            }
            pickPostImageLauncher.launch(intent)
        }
    }
}
